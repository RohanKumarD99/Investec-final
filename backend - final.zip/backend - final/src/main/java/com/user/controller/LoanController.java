package com.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.user.model.Loans;
import com.user.service.LoanService;

@CrossOrigin("*")
@RestController
@RequestMapping("/Loanuser")
public class LoanController {

    @Autowired
    public LoanService loanService;

    @PostMapping("/add")
    public Loans getdata(@RequestBody Loans loans) {

        return loanService.adddata(loans);
    }
}