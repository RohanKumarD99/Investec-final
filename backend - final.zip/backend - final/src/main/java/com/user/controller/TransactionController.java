package com.user.controller;

import com.user.service.TransactionService;
import com.user.model.Transactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class TransactionController {

    @Autowired
    public TransactionService transactionService;

    @PostMapping("/add")
    public Transactions getdata(@RequestBody Transactions transactions) {

        return transactionService.adddata(transactions);
    }
}
