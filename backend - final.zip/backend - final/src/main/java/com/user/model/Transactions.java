package com.user.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transactions {
	@Id
	private String accountno;
	private String recipientname;
	private String bankname;
	private String ifsccode;
	private String amount;

	public String getAccountno() {
		return accountno;
	}

	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}

	public String getRecipientname() {
		return recipientname;
	}

	public void setRecipientname(String recipientname) {
		this.recipientname = recipientname;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Transactions(String accountno, String recipientname, String bankname, String ifsccode, String amount) {
		this.accountno = accountno;
		this.recipientname = recipientname;
		this.bankname = bankname;
		this.ifsccode = ifsccode;
		this.amount = amount;
	}

	public Transactions() {
		super();
	}
}
