package com.user.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Loans {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String dateofapplication;
    private String amountapplied;
    private String term;
    private String equity;
    private String purpose;
    private String typeofproperty;
    private String addressofproperty;
    private String nameofborrower;
    private String mothersname;
    private String birthday;
    private String birthplace;
    private String civilstatus;
    private String age;
    private String nationality;
    private String numberofdependents;
    private String permanentaddress;
    private String residence;
    private String mobilephoneno;
    private String emailaddress;
    private String nameofpresentemployer;
    private String dateofemployment;
    private String businessaddress;
    private String businesstelephoneno;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDateofapplication() {
        return dateofapplication;
    }

    public void setDateofapplication(String dateofapplication) {
        this.dateofapplication = dateofapplication;
    }

    public String getAmountapplied() {
        return amountapplied;
    }

    public void setAmountapplied(String amountapplied) {
        this.amountapplied = amountapplied;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getEquity() {
        return equity;
    }

    public void setEquity(String equity) {
        this.equity = equity;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getTypeofproperty() {
        return typeofproperty;
    }

    public void setTypeofproperty(String typeofproperty) {
        this.typeofproperty = typeofproperty;
    }

    public String getAddressofproperty() {
        return addressofproperty;
    }

    public void setAddressofproperty(String addressofproperty) {
        this.addressofproperty = addressofproperty;
    }

    public String getNameofborrower() {
        return nameofborrower;
    }

    public void setNameofborrower(String nameofborrower) {
        this.nameofborrower = nameofborrower;
    }

    public String getMothersname() {
        return mothersname;
    }

    public void setMothersname(String mothersname) {
        this.mothersname = mothersname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getBirthplace() {
        return birthplace;
    }

    public void setBirthplace(String birthplace) {
        this.birthplace = birthplace;
    }

    public String getCivilstatus() {
        return civilstatus;
    }

    public void setCivilstatus(String civilstatus) {
        this.civilstatus = civilstatus;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getNumberofdependents() {
        return numberofdependents;
    }

    public void setNumberofdependents(String numberofdependents) {
        this.numberofdependents = numberofdependents;
    }

    public String getPermanentaddress() {
        return permanentaddress;
    }

    public void setPermanentaddress(String permanentaddress) {
        this.permanentaddress = permanentaddress;
    }

    public String getResidence() {
        return residence;
    }

    public void setResidence(String residence) {
        this.residence = residence;
    }

    public String getMobilephoneno() {
        return mobilephoneno;
    }

    public void setMobilephoneno(String mobilephoneno) {
        this.mobilephoneno = mobilephoneno;
    }

    public String getEmailaddress() {
        return emailaddress;
    }

    public void setEmailaddress(String emailaddress) {
        this.emailaddress = emailaddress;
    }

    public String getNameofpresentemployer() {
        return nameofpresentemployer;
    }

    public void setNameofpresentemployer(String nameofpresentemployer) {
        this.nameofpresentemployer = nameofpresentemployer;
    }

    public String getDateofemployment() {
        return dateofemployment;
    }

    public void setDateofemployment(String dateofemployment) {
        this.dateofemployment = dateofemployment;
    }

    public String getBusinessaddress() {
        return businessaddress;
    }

    public void setBusinessaddress(String businessaddress) {
        this.businessaddress = businessaddress;
    }

    public String getBusinesstelephoneno() {
        return businesstelephoneno;
    }

    public void setBusinesstelephoneno(String businesstelephoneno) {
        this.businesstelephoneno = businesstelephoneno;
    }

    public Loans(Long id, String dateofapplication, String amountapplied, String term, String equity, String purpose, String typeofproperty, String addressofproperty, String nameofborrower, String mothersname, String birthday, String birthplace, String civilstatus, String age, String nationality, String numberofdependents, String permanentaddress, String residence, String mobilephoneno, String emailaddress, String nameofpresentemployer, String dateofemployment, String businessaddress, String businesstelephoneno) {
        this.id = id;
        this.dateofapplication = dateofapplication;
        this.amountapplied = amountapplied;
        this.term = term;
        this.equity = equity;
        this.purpose = purpose;
        this.typeofproperty = typeofproperty;
        this.addressofproperty = addressofproperty;
        this.nameofborrower = nameofborrower;
        this.mothersname = mothersname;
        this.birthday = birthday;
        this.birthplace = birthplace;
        this.civilstatus = civilstatus;
        this.age = age;
        this.nationality = nationality;
        this.numberofdependents = numberofdependents;
        this.permanentaddress = permanentaddress;
        this.residence = residence;
        this.mobilephoneno = mobilephoneno;
        this.emailaddress = emailaddress;
        this.nameofpresentemployer = nameofpresentemployer;
        this.dateofemployment = dateofemployment;
        this.businessaddress = businessaddress;
        this.businesstelephoneno = businesstelephoneno;
    }

    public Loans() {
        super();
    }
}