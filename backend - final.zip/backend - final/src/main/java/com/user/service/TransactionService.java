package com.user.service;

import com.user.model.Transactions;
import com.user.repository.TransactionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransactionService {

    @Autowired
    public TransactionsRepository transactionsRepository;

    public Transactions adddata(Transactions transactions) {

        return transactionsRepository.save(transactions);
    }


}
