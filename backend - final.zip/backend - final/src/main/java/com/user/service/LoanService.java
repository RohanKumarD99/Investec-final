package com.user.service;

        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;
        import com.user.model.Loans;
        import com.user.repository.LoanRepository;

@Service
public class LoanService {


    @Autowired
    public LoanRepository loansRepository;

    public Loans adddata(Loans loans) {

        return loansRepository.save(loans);
    }


}