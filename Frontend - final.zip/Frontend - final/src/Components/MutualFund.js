import React from "react";

function Mutualfund() {
    return (
        <div>
            <h1>Welcome to the Mutualfund department</h1>
        </div>
    )
}

export default Mutualfund;