import React from "react";

function Homeloan() {
    return (
        <div>
            <h1>Welcome to the Home loan department</h1>
        </div>
    )
}

export default Homeloan;