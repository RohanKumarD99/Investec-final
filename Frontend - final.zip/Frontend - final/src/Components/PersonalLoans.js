import React from "react";

function Personal() {
    return (
        <div>
            <h1>all personal loans are listed below</h1>
        </div>
    )
}

export default Personal;