import React, { useState } from "react";
import dat from "../CSS/Loanapproval.css"
import { useDispatch } from "react-redux";
import axios from "axios";

function Loanapprovalform() {
    const dispatch = useDispatch();
    const [dateofApplication, SetDateofapplication] = useState("");
    const [amountapplied, SetAmountappliedfor] = useState("");
    const [term, SetTerm] = useState("");
    const [equity, SetEquity] = useState("");
    const [purpose, SetPurpose] = useState("");
    const [typeofproperty, SetTypeofproperty] = useState("");
    const [addressofproperty, SetAddressofproperty] = useState("");
    const [nameofborrower, SetNameofborrower] = useState("");
    const [mothersname, SetMothersname] = useState("");
    const [birthday, SetBirthday] = useState("");
    const [birthplace, SetBirthplace] = useState("");
    const [civilstatus, SetCivilstatus] = useState("");
    const [age, SetAge] = useState("");
    const [nationality, SetNationality] = useState("");
    const [numberofdependents, SetNoofdependents] = useState("");
    const [permanentaddress, SetPermanentaddress] = useState("");
    const [residence, SetResidence] = useState("");
    const [mobilePhoneno, Setmobilephoneno] = useState("");
    const [emailaddress, SetEmailaddress] = useState("");
    const [nameofpresentemployer, SetNameofpresentemployer] = useState("");
    const [dateofemployment, SetDateofemployment] = useState("");
    const [businessaddress, SetBusinessaddress] = useState("");
    const [businesstelephoneno, SetBusinesstelephoneno] = useState("");

    const Applyloan = () => { dispatch(HandleClick()) }

    const HandleClick = () => {

        const data = {
            dateofapplication: dateofApplication,
            amountapplied: amountapplied,
            term: term,
            equity: equity,
            purpose: purpose,
            typeofproperty: typeofproperty,
            addressofproperty: addressofproperty,
            nameofborrower: nameofborrower,
            mothersname: mothersname,
            birthday: birthday,
            birthplace: birthplace,
            civilstatus: civilstatus,
            age: age,
            nationality: nationality,
            numberofdependents: numberofdependents,
            permanentaddress: permanentaddress,
            residence: residence,
            mobilephoneno: mobilePhoneno,
            emailaddress: emailaddress,
            nameofpresentemployer: nameofpresentemployer,
            dateofemployment: dateofemployment,
            businessaddress: businessaddress,
            businesstelephoneno: businesstelephoneno,

        }
        return async function (dispatch, getState) {

            await axios.post("http://localhost:9001/Loanuser/add", data).then((response) => { alert("Successful"); }).catch((error) => { console.log(error); })
        }
    }

    return (
        <div className="data_outer">
            <div>
                <h1>Loans Department</h1>
                <h3>Please fill all the details below and wait for bank approval</h3>
            </div>
            <div className="data_inner">
                <div className="data_inner12">
                    <div className="data_one">
                        <h2 className="head_data">Loan Details</h2>
                        <label className="loan_data">Date Of application:</label><br />
                        <input id="date of application" className="loan_applied" onChange={(e) => SetDateofapplication(e.target.value)}></input><br />
                        <br />
                        <label className="loan_data">Amount Applied for</label><br />
                        <input id="Amount applied for" className="loan_applied" onChange={(e) => SetAmountappliedfor(e.target.value)}></input><br />
                        <br />
                        <label className="loan_data">Term</label><br />
                        <input id="Amount applied for" className="loan_applied" onChange={(e) => SetTerm(e.target.value)}></input><br />
                        <br />
                        <label className="loan_data">Equity Availble</label><br />
                        <input type="checkbox" onChange={(e) => SetEquity(e.target.value)} />
                        <span>Cheque</span>
                        <input type="checkbox" />
                        <span>Lot</span><br />
                        <br />
                        <label className="loan_data">Purpose</label><br />
                        <textarea id="freeform" name="freeform" rows="4" cols="50" onChange={(e) => SetPurpose(e.target.value)}></textarea>
                        <h2 className="head_data">Collateral Details</h2>
                        <label className="loan_data">Choose the type of property</label>
                        <br />
                        <br />
                        <select id="Property" onChange={(e) => SetTypeofproperty(e.target.value)}>
                            <option>Select Your Option</option>
                            <option value="House">House and lot</option>
                            <option value="Housetown">Townhouse</option>
                            <option value="Lot">Lot</option>
                            <option value="others">others</option>
                        </select>
                        <br />
                        <br />
                        <label className="loan_data">Address Of property:</label><br />
                        <br />
                        <textarea id="freeform" name="freeform" rows="4" cols="50" onChange={(e) => SetAddressofproperty(e.target.value)}></textarea>
                        <br />
                    </div>
                </div>
                <div className="data_inner14">
                    <h2 className="head_data">Personal Details</h2>
                    <label className="loan_data">Name Of Borrower</label><br />
                    <input id="Name Of Borrower" className="loan_applied" onChange={(e) => SetNameofborrower(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Mother's Maidenname</label><br />
                    <input id="Mother's Maidenname" className="loan_applied" onChange={(e) => SetMothersname(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Birthday</label><br />
                    <input id="Birthday" className="loan_applied" onChange={(e) => SetBirthday(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Birthplace</label><br />
                    <input id="Birthplace" className="loan_applied" onChange={(e) => SetBirthplace(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Civil Status</label><br />
                    <input id="Civil Status" className="loan_applied" onChange={(e) => SetCivilstatus(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Age</label><br />
                    <input id="Age" className="loan_applied" onChange={(e) => SetAge(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Nationality</label><br />
                    <input id="Nationality" className="loan_applied" onChange={(e) => SetNationality(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">No.of Dependents</label><br />
                    <input id="No.of Dependents" className="loan_applied" onChange={(e) => SetNoofdependents(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Permanent Home Address</label><br />
                    <br />
                    <textarea id="freeform" name="freeform" rows="4" cols="50" onChange={(e) => SetPermanentaddress(e.target.value)}></textarea>
                    <br />
                    <label className="loan_data">House</label>
                    <br />
                    <select onChange={(e) => SetResidence(e.target.value)}>
                        <option>owned</option>
                        <option>rented</option>
                        <option>owned by parents</option>
                        <option>others</option>
                    </select>
                    <br />
                    <br />
                    <label className="loan_data">Mobile-no</label><br />
                    <input id="Mobile-no" className="loan_applied" onChange={(e) => Setmobilephoneno(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Email-Address</label><br />
                    <input id="Email-Address" className="loan_applied" onChange={(e) => SetEmailaddress(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Name of Present Employer/Business</label><br />
                    <input id="Employer" className="loan_applied" onChange={(e) => SetNameofpresentemployer(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Date of Employment</label><br />
                    <input id="Date of Employment" className="loan_applied" onChange={(e) => SetDateofemployment(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Business Address</label><br />
                    <input id="Business Address" className="loan_applied" onChange={(e) => SetBusinessaddress(e.target.value)}></input><br />
                    <br />
                    <label className="loan_data">Business Telephone no</label><br />
                    <input id="Telephone no" className="loan_applied" onChange={(e) => SetBusinesstelephoneno(e.target.value)}></input><br />
                    <button onClick={Applyloan}>Apply For Loan</button>
                </div>
            </div>
        </div>
    )
}

export default Loanapprovalform;