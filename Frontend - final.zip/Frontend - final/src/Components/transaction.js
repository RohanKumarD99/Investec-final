import React, { useState } from "react";
import UserDashboard from "./UserDashboard";
import trans from "../CSS/transaction.css";
import img23 from "../Images/profile.jpg";
import { useDispatch } from "react-redux";
import axios from "axios";

function Transcations() {
    const dispatch = useDispatch();
    const [accountno, setAccountno] = useState();
    const [recipientname, setRecipientName] = useState();
    const [bankname, setBankName] = useState();
    const [ifsccode, setIfscCode] = useState();
    const [amount, setAmount] = useState();

    const Apply = () => { dispatch(HandleClick()) }
    const HandleClick = () => {

        const data = {

            accountno: accountno,
            recipientname: recipientname,
            bankname: bankname,
            ifsccode: ifsccode, 
            amount: amount
        }
        console.log(data);
        return async function (dispatch, getState) {

            await axios.post("http://localhost:9001/user/add", data).then((response) => { alert("Successful"); }).catch((error) => { console.log(error); })
        }
    }

    return (
        <div className="MAIN_SECTION">
            <div>
                <div className="user_main">
                    <img src={img23} className="user_img"></img>
                    <div>
                        <h2 className="user_heading">User Profile</h2>
                    </div>
                    <div className="user_profile">
                        <h3>Rohan Kumar</h3>
                        <h3>rohan@gmail.com</h3>
                        <h3>RohanKumar</h3>
                        <h3>9382902848</h3>
                        <h3 >flat:no-982,Mumbai</h3>
                    </div>
                </div>
            </div>
            <div>
                <div className="Amount">
                    <h1 className="Amount_head">Transfer Amount</h1>
                    <form className="Amount_form">
                        <label className="Amount_one">Account Number</label>
                        <br />
                        <input onChange={(e) => setAccountno(e.target.value)} type="text" id="text" className="Amount_two"></input>
                        <br />
                        <label className="Amount_one">Recipient Name</label>
                        <br />
                        <input onChange={(e) => setRecipientName(e.target.value)} type="text" id="text" className="Amount_two"></input>
                        <br />
                        <label className="Amount_one">Bank Name</label>
                        <br />
                        <input onChange={(e) => setBankName(e.target.value)} type="text" id="text" className="Amount_two"></input>
                        <br />
                        <label className="Amount_one">IFSC Code</label>
                        <br />
                        <input onChange={(e) => setIfscCode(e.target.value)} type="text" id="text" className="Amount_two"></input>
                        <br />
                        <label className="Amount_one">Amount</label>
                        <br />
                        <input onChange={(e) => setAmount(e.target.value)} type="text" id="text" className="Amount_two"></input>
                        <button className="Amount_Four" onClick={Apply}>Send Amount</button>
                    </form>
                </div>
                <div>
                    <div className="Amount">
                        <h1 className="Amount_head">Self Deposit</h1>
                        <form className="Amount_form">
                            <label className="Amount_one">Account Number</label>
                            <br />
                            <input type="text" id="text" className="Amount_two"></input>
                            <br />
                            <label className="Amount_one">Amount</label>
                            <br />
                            <input type="text" id="text" className="Amount_two"></input>
                            <br />
                            <label className="Amount_one">Date of Deposit</label>
                            <br />
                            <input type="text" id="text" className="Amount_two"></input>
                            <br />
                            <label className="Amount_one">Branch</label>
                            <br />
                            <input type="text" id="text" className="Amount_two"></input>
                            <br />
                            <button className="Amount_Four">Deposit</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Transcations;