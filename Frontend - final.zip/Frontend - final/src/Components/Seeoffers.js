import React from "react";
import Img99 from "../Images/1.jpg"
import Img98 from "../Images/2.jpg"
import Img97 from "../Images/3.jpg"
import Img96 from "../Images/4.jpg"
import Img95 from "../Images/5.jpg"
import Img94 from "../Images/6.jpg"
import Img93 from "../Images/7.jpg"
import Img92 from "../Images/8.jpg"
import stylesheet from "../CSS/seeoffers.css"

function Offers() {
    return (
        <div>
            <div className="Offers_main">
                <div className="Offers_inner1">
                    <img src={Img99} className="inner1_img" />
                    <h2 className="inner1_head">Big Sale @Amazon</h2>
                    <h5 className="inner1_head1">Maximum discount up to ₹250 on orders above ₹400</h5>
                    <button className="inner1_btn">See more</button>
                </div>
                <div className="Offers_inner2">
                    <img src={Img98} className="inner2_img" />
                    <h2 className="inner2_head">Get 30% Discount on using investec credit cards</h2>
                    <h5 className="inner2_head1">Get 12% off up to Rs. 1800 on Domestic Flights
                        <br /> with Yatra.</h5>
                    <button className="inner2_btn">See more</button>
                </div>
            </div>
            <div className="Offers_main2">
                <div className="Offers_inner3">
                    <img src={Img97} className="inner3_img" />
                    <h2 className="inner3_head">Club Mahindra- GoZest Membership At 12%</h2>
                    <h5 className="inner3_head1">EMI payment options also available for 30% down payment plan.</h5>
                    <button className="inner3_btn">See more</button>
                </div>
                <div className="Offers_inner4">
                    <img src={Img96} className="inner4_img" />
                    <h2 className="inner4_head">Tata Cliq: Exclusive 15% instant discount for customers</h2>
                    <h5 className="inner4_head1">Tata CLiQ Offer - 15% off at Tata CLiQ Mall</h5>
                    <button className="inner4_btn">See more</button>
                </div>
            </div>
            <div className="Offers_main3">
                <div className="Offers_inner5">
                    <img src={Img95} className="inner5_img" />
                    <h2 className="inner5_head">EaseMyTrip exclusive offer on Net Banking!</h2>
                    <h5 className="inner5_head1">Flat 10% Up to INR 1,200 on Domestic Flights, on minimum order of ₹ 5000</h5>
                    <button className="inner5_btn">See more</button>
                </div>
                <div className="Offers_inner6">
                    <img src={Img94} className="inner6_img" />
                    <h2 className="inner6_head">Treat Yourself With This Zomato Offer With ICICI Bank!</h2>
                    <h5 className="inner6_head1">Now pay using ICICI Bank Net Banking on Zomato app.</h5>
                    <button className="inner6_btn">See more</button>
                </div>
            </div>
            <div className="Offers_main4">
                <div className="Offers_inner7">
                    <img src={Img93} className="inner7_img" />
                    <h2 className="inner7_head">Get Cashback of up to Rs 7,500 on Multiple Xiaomi</h2>
                    <h5 className="inner7_head1">Earn Rs 250 Amazon Pay Voucher</h5>
                    <button className="inner7_btn">See more</button>
                </div>
                <div className="Offers_inner8">
                    <img src={Img92} className="inner8_img" />
                    <h2 className="inner8_head">SonyLIV : Exclusive offer on Net Banking!</h2>
                    <h5 className="inner8_head1">SonyLIV : Exclusive offer on Net Banking!</h5>
                    <button className="inner8_btn">See more</button>
                </div>
            </div>
        </div>
    )
}

export default Offers;