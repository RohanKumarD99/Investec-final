import React from "react";
import img23 from "../Images/profile.jpg";
import user from "../CSS/UserDashboard.css";
import { Link } from "react-router-dom";

function UserDashboard() {
    return (
        <div className="user_flex">
            <div>
                <div className="user_main">
                    <img src={img23} className="user_img"></img>
                    <div>
                        <h2 className="user_heading">User Profile</h2>
                    </div>
                    <br/>
                    <div className="user_profile">
                        <h3>Rohan Kumar</h3>
                        <h3>rohan@gmail.com</h3>
                        <h3>RohanKumar</h3>
                        <h3>9382902848</h3>
                        <h3 >flat:no-982,Mumbai</h3>
                    </div>
                </div>
            </div>
            <div className="loan_dashboard">
                <div className="Loan_main">
                    <div>
                        <h1 className="loan_personal">Loans</h1>
                    </div>
                    <div className="Loan_description">
                        <h2>Interest @ 8%</h2>
                        <h2>One needs to be of a minimum age of 21 years and should have a valid set of documents like ID, income and residence proof, among other documents, to avail a Personal Loan from Axis Bank.</h2>
                        <h2>To ease the burden of paying off the Personal Loan immediately, you may opt for the EMI (Equated Monthly Instalment) facility. The repayment tenure can range from anywhere between 12 to 60 months. If you’re an Axis Bank customer, you can avail the best rates for Personal Loans!</h2>
                        <h2>Get a personal loan between Rs.50000 to Rs.40,00,000</h2>
                    </div>
                    <div>
                        <Link to = "/Loanapprovalform"><button className="Loan_Button">Apply Now</button></Link>
                    </div>
                </div>
                <div className="Loan_main">
                    <div>
                        <h1 className="loan_personal">Credit-Card</h1>
                    </div>
                    <div className="Loan_description">
                        <h2>Interest @ 8%</h2>
                        <h2>One needs to be of a minimum age of 21 years and should have a valid set of documents like ID, income and residence proof, among other documents, to avail a Personal Loan from Axis Bank.</h2>
                        <h2>To ease the burden of paying off the Personal Loan immediately, you may opt for the EMI (Equated Monthly Instalment) facility. The repayment tenure can range from anywhere between 12 to 60 months. If you’re an Axis Bank customer, you can avail the best rates for Personal Loans!</h2>
                        <h2>Get a personalized card between Rs.50000 to Rs.40,00,000</h2>
                    </div>
                    <div>
                        <button className="Loan_Button">Apply Now</button>
                    </div>
                </div>
                <div className="Loan_main">
                    <div>
                        <h1 className="loan_personal">Transactions</h1>
                    </div>
                    <div className="Loan_description">
                        <h2>Transactions and Payments</h2>
                        <h2>Bank transaction data is data that shows cash in and cash out of an account</h2>
                        <h2>All the transcations,payments and other account details will be displayed and transcations can be done.You can send and receive the Amount will be displayed.information regarding account details and etc....!</h2>
                        <h2>Click the Button to view the details and follow the Process</h2>
                    </div>
                    <div>
                        <Link to='/transaction'><button className="Loan_Button">Click Here</button></Link>
                    </div>
                </div>
                <div className="Loan_main">
                    <div>
                        <h1 className="loan_personal">Cheque-book-Request</h1>
                    </div>
                    <div className="Loan_description">
                        <h2>Request for checkbook</h2>
                        <h2> Requirments</h2>
                        <h2>For reqursting a cheque book you need to complete more  than 5 transcations.</h2>
                        <h2>You need to have a minimum balance of Rs.2,00,000</h2>
                        <h2>Follow the on-screen instructions to complete the request for a new cheque book. This may involve providing your account number,
                            <br /> selecting the number of cheques you want in the new book, and confirming your request.</h2>
                    </div>
                    <div>
                        <button className="Loan_Button">Apply Now</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserDashboard;