import React from "react";
import { useRef, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import Reg from "../CSS/Register.css";
import { useNavigate } from "react-router-dom";
import Mutualfund from "./MutualFund";
import Personal from "./PersonalLoans";
import UserDashboard from "./UserDashboard";
import { useDispatch, useSelector } from "react-redux";
import { registerUser } from "../redux/Registerslice";



const isEmpty = value => value.trim() === '';
const istencharacters = value => value.trim().length === 10;



function Register() {

    const [firstname, setfirstname] = useState("");
    const [lastname, setlastname] = useState("");
    const [phoneno, setphoneno] = useState("");
    const [address, setaddress] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");

    const dispatch = useDispatch();
    const user = useSelector((state) => state.register.user);


    const [formInputsValidity, setformInputsValidity] = useState({
        FirstName: true,
        LastName: true,
        Phoneno: true,
        Address: true,
        Email: true,
        password: true,


    })


    const firstNameRef = useRef();
    const lastNameRef = useRef();
    const phoneNumberRef = useRef();
    const AddressRef = useRef();
    const emailAddressRef = useRef();
    const passwordRef = useRef();


    const confirmHandler = (event) => {
        event.preventDefault();

        const enteredFirstName = firstNameRef.current.value;
        const enteredLastName = lastNameRef.current.value;
        const enteredPhoneNo = phoneNumberRef.current.value;
        const enteredAddress = AddressRef.current.value;
        const enteredEmail = emailAddressRef.current.value;
        const enteredpassword = passwordRef.current.value;


        const enteredFirstNameIsValid = !isEmpty(enteredFirstName);
        const enteredLastNameIsValid = !isEmpty(enteredLastName);
        const enteredPhonenoIsValid = istencharacters(enteredPhoneNo);
        const enteredAddressIsValid = !isEmpty(enteredAddress);
        const enteredEmailIsValid = !isEmpty(enteredEmail);
        const enteredpasswordIsValid = !isEmpty(enteredpassword);

        setformInputsValidity({

            FirstName: enteredFirstNameIsValid,
            LastName: enteredLastNameIsValid,
            Phoneno: enteredPhonenoIsValid,
            Address: enteredAddressIsValid,
            Email: enteredEmailIsValid,
            password: enteredpasswordIsValid,

        })

        const formIsValid = enteredFirstNameIsValid && enteredLastNameIsValid && enteredPhonenoIsValid && enteredAddressIsValid && enteredEmailIsValid && enteredpasswordIsValid;

        if (formIsValid) {
            dispatch(registerUser({
                firstname: firstname,
                lastname: lastname,
                phoneno: phoneno,
                address: address,
                emailaddress: email,
                password: password
            })
            )
        }

    }

    return (
        <div id="formContainer">
            <form id="form" action="#" method="POST" onSubmit={confirmHandler}>
                <div className="form_fieldset">
                    <h1>Registration Form</h1>
                    <div>
                        <input type="text" name="fName" id="fName" placeholder="First Name"
                            ref={firstNameRef} onChange={(e) => setfirstname(e.target.value)} />
                        {!formInputsValidity.FirstName && <p className="para_fn">Enter a valid Firstname</p>}
                    </div>
                    <div>
                        <input type="text" name="lName" id="lName" placeholder="Last Name"
                            ref={lastNameRef} onChange={(e) => setlastname(e.target.value)} />
                        {!formInputsValidity.LastName && <p className="para_ln">Enter a valid Lastname</p>}
                    </div>
                    <div>
                        <input type="text" name="npi" id="Phoneno" placeholder="Phone-no"
                            ref={phoneNumberRef} onChange={(e) => setphoneno(e.target.value)} />
                        {!formInputsValidity.Phoneno && <p className="para_phone">Enter a valid Phoneno</p>}
                    </div>
                    <div>
                        <input type="text" name="address" id="address" placeholder="Address" ref={AddressRef} onChange={(e) => setaddress(e.target.value)} />
                        {!formInputsValidity.Address && <p className="para_address">Enter a valid Address</p>}
                    </div>
                    <div>
                        <input type="email" name="email" id="email" placeholder="Email Address"
                            ref={emailAddressRef} onChange={(e) => setemail(e.target.value)} />
                        {!formInputsValidity.Email && <p className="para_email">Enter a valid Email</p>}
                    </div>
                    <div>
                        <input type="Password" name="password" id="password" placeholder="Password" ref={passwordRef} onChange={(e) => setpassword(e.target.value)} />
                        {!formInputsValidity.password && <p className="para_password1">Enter a valid Password</p>}
                        <div />
                        <br /><br />
                        <div className="buttons_flex">
                            <input type="submit" name="submit" id="click" />
                        </div>
                    </div>
                </div>
            </form>
        </div>
    )
}


export default Register;