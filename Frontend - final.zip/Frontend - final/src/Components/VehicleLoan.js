import React from "react";

function VehicleLoan() {
    return (
        <div>
            <h1>Welcome to the VehicleLoan department</h1>
        </div>
    )
}

export default VehicleLoan;