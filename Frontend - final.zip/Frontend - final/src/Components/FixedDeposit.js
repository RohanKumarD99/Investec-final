import React from "react";

function FixedDeosit() {
    return (
        <div>
            <h1>Welcome to the FixedDeosit department</h1>
        </div>
    )
}

export default FixedDeosit;