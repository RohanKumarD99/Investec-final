import React from "react";

function Help() {
    <div>
        Hello
    </div>
}

export default Help;