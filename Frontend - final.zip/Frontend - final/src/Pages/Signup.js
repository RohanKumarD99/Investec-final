import React from "react";
import Register from "../Components/Register";

function Signup() {
    return (
        <div>
            <Register />
        </div>
    )
}

export default Signup;