import React from "react";
import Signin from "../Components/Signin";

function Login() {
    return (
        <div>
            <Signin />
        </div>
    )
}

export default Login;