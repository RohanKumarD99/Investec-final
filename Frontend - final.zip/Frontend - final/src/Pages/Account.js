import React from 'react'
import DigitalAccount from '../Components/DigitalAccount';

function Account() {
    return (
        <div>
            <DigitalAccount />
        </div>
    )
}

export default Account;