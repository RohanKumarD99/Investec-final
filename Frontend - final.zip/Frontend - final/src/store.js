import { configureStore } from "@reduxjs/toolkit";
import RegisterReducer from "./redux/Registerslice";


export default configureStore({
    reducer: {
        register: RegisterReducer
    },
});